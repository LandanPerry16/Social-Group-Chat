The server and client both must be run.
New users can be registered and their usernames and sha-512 hashed passwords can be viewed in users.txt.

Features that were planned but do not function are:
User Profile
Edit Profile
Friends List

We did experience issues caused by different group members using different IDE's.
If this seems to be an issue when grading, the IDE we finalized the project in and recorded the demo from was IntelliJ.

For testing purposes, the current users are:
AOppenh, pswd1
CPolanka, pswd2
ABrown, pswd3
LPerry, pswd4
DBurgos, pswd5
